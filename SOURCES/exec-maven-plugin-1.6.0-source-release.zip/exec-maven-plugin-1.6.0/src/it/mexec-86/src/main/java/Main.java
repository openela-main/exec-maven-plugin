import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;

public class Main
{
    public static void main( String[] args ) throws Exception
    {
        System.out.println( "1. System.out line" );
        System.err.println( "2. System.err line" );
        System.out.println( "3. System.out line" );
        System.err.println( "4. System.err line" );
        System.out.println( "5. System.out line" );
    }
}
